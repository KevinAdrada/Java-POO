//este programa simulara un deposito y retiro dentro de dos cuentas bancarias 
package cuentabancaria;

//by KevinAdrada
public class CuentaBancaria {
    
    //creamos los atributos privados
    private String numeroCuenta;
    private double saldo;

    
    //metodo de acceso setter, para iniciar o establecer la variable numeroCuenta
    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }
    //metodo de acceso getter para obtener el número de cuenta
    public String getNumeroCuenta() {
        return numeroCuenta;
    }
    
    
    //metodo de acceso setter, para iniciar o establecer la variable numeroCuenta
    public void setSaldo(double saldo) {
        if(saldo<0){
            System.out.println("El saldo de la cuenta \""+numeroCuenta+ "\" es invalido se establecera en 0");
            this.saldo=0;
        }else{
        this.saldo = saldo;
        }
    }
    //metodo de acceso getter para obtener el saldo actual
    public double getSaldo() {
        return saldo;
    }
    

    //metodo para depositar dinero
    public void depositar(double monto) {
        //si el monto a depositar es menor o igual a 0 se muestra como valor invalido
        if (monto <= 0) {
            System.out.println("Monto de deposito invalido.");
        } else {
            //se suma el monto al saldo de la cuenta
            saldo += monto;
            System.out.println("\nSe depositaron $" + monto + " en la cuenta \"" + numeroCuenta+"\". Nuevo saldo: $"+saldo);
        }
    }

    //metodo para retirar dinero
    public void retirar(double monto) {
        
        //si el monto a retirar es negativo se muestra como invalido 
        if (monto < 0) {
            System.out.println("Monto inválido para hacer retiro en la cuenta \"" + numeroCuenta+"\"");
            
        //si supera el saldo dispoible se muestra saldo insuficiente
        } else if(monto > saldo){
            System.out.println("Saldo Insuficiente para restirar $"+monto+" de la cuenta \"" + numeroCuenta+"\"");
            
        //si es un moonto valido se resta ese monto al saldo de la cuenta y se muestra retiro exitoso
        } else {
            saldo -= monto;
            System.out.println("Se retiraron $" + monto + " de la cuenta \"" + numeroCuenta+"\"");
        }
    }

    
}