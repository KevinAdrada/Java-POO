package cuentabancaria;

public class Main {
    //creamos el metodo principal 
    public static void main(String[] args) {
        //Creamos los objetos para las dos cuentas bancarias
        CuentaBancaria cuenta1 = new CuentaBancaria();
        CuentaBancaria cuenta2 = new CuentaBancaria();
        
        //establezco un valor para el numero de cuenta para cada cuenta
        cuenta1.setNumeroCuenta("24680");
        cuenta2.setNumeroCuenta("13579");
        
        //establezco un valor como saldo inicial de cada cuenta
        cuenta1.setSaldo(1000);
        cuenta2.setSaldo(500);

        //deposito y retiro en la cuenta 1
        cuenta1.depositar(200);
        cuenta1.retirar(150);

        //deposito y retiro en la cuenta 2
        cuenta2.depositar(300);
        cuenta2.retirar(1000);

        // Mostrar saldo final de ambas cuentas
        System.out.println("\nSaldo Final");
        System.out.println("Cuenta \"" + cuenta1.getNumeroCuenta() + "\": $" + cuenta1.getSaldo());
        System.out.println("Cuenta \"" + cuenta2.getNumeroCuenta() + "\": $" + cuenta2.getSaldo());
    }
}

