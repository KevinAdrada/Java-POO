//este programa muestra el titulo, autor y numero de paginas de dos libros realizando una validacion en el numero de paginas de los libros 
package libro;

//by KevinAdrada
public class Libro {
    
    //creamos los atributos privados
    private String titulo;
    private String autor;
    private int numPaginas;

    //metodo de acceso setter, para iniciar o establecer la variable nombre
    public void setTitulo(String nombre) {
        this.titulo = nombre;
    }
    //metodo de acceso getter para obtener el nombre
    public String getTitulo() {
        return titulo;
    }

    
    //metodo de acceso setter, para iniciar o establecer la variable autor
    public void setAutor(String autor) {
        this.autor = autor;
    }
    //metodo de acceso getter para obtener el autor
    public String getAutor() {
        return autor;
    }

    
    //metodo de acceso setter, para iniciar o establecer la variable numPaginas
    public void setNumPaginas(int numPaginas) {
        
        //se indica que el libro no puede tener menos de 10 paginas
        if(numPaginas<10){
            System.out.println("Numero de paginas invalido");
            this.numPaginas=0;
        }else{
        this.numPaginas = numPaginas;
        }
    }
    //metodo de acceso getter para obtener el numero de paginas
    public int getNumPaginas() {
        return numPaginas;
    }
}
