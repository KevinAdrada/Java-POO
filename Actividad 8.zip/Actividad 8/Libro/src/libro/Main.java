
package libro;


public class Main {
    //creamos el metodo principal 
    public static void main(String[] args) {
        //creamos los objetos para el libro 1 y 2 respectivamente
        Libro libro1 = new Libro();
        Libro libro2 = new Libro();
        
        //establezco un valor para la variable titulo para cada libro
        libro1.setTitulo("Romeo y Julieta");
        libro2.setTitulo("La Odisea");
        
        //establezco un valor para la variable autor para cada libro
        libro1.setAutor("William Shakespeare");
        libro2.setAutor("Homero");
        
        //establezco un valor para la variable numPaginas para cada libro
        libro1.setNumPaginas(100);
        libro2.setNumPaginas(8);
        
        //muestro los datos correspondientes para cada libro 
        System.out.println("Libro 1");
        System.out.println("Titulo: "+libro1.getTitulo()+"\nAutor: "+libro1.getAutor()+"\nNumero de Paginas: "+libro1.getNumPaginas());
        System.out.println("\nLibro 2");
        System.out.println("Titulo: "+libro2.getTitulo()+"\nAutor: "+libro2.getAutor()+"\nNumero de Paginas: "+libro2.getNumPaginas());
    }
}
