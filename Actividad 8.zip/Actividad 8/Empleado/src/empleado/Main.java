
package empleado;


public class Main {
    //creamos el metodo principal 
    public static void main(String[] args) {
        //creamos un objeto 
        Empleado nombre = new Empleado();

        //establezco un valor para las variables nombre y salario
        nombre.setNombre("Pepito Perez");
        nombre.setSalario(1000000);
        
        //muestro en consola el valor del nombre establecido y el salario del empleado
        System.out.println("Empleado: " + nombre.getNombre());
        System.out.println("Salario actual: " + nombre.getSalario());
        
        //establezco un valor para el porcentaje del aumento que se realizara al salario del empleado 
        nombre.aumentarSalario(10);
        
        //muestro en consola el valor del salario despues de realizarle el aumento 
        System.out.println("Salario final con el aumento: " + nombre.getSalario());
    }

}
