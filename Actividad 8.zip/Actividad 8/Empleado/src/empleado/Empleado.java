//este programa valida el salario de un empleado y si lo es realiza un aumento 
package empleado;

//by KevinAdrada
public class Empleado {
    
    //creamos los atributos privados nombre y salario
    private String nombre;
    private double salario;
    
    //creo una variable para el salario minimo 
    int salarioMinimo = 1420000;
    
    //metodo de acceso setter, para iniciar o establecer la variable nombre
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    //metodo de acceso getter para obtener el nombre
    public String getNombre() {
        return nombre;
    }

    //metodo de acceso setter, para iniciar o establecer la variable salario
    public void setSalario(double salario) {
        
        //si el salario del emplado es menor al salario minimo, su salario se modifica para que sea igual al salario minimo 
        if (salario < salarioMinimo) {
            System.out.println("Salario invalido. No puede ser menor al salario minimo");
            this.salario = salarioMinimo;
        } else {
            this.salario = salario;
        }
    }
    //metodo de acceso getter para obtener el salario
    public double getSalario() {
        return salario;
    }

    //Método para aumentar salario por porcentaje
    public void aumentarSalario(double porcentaje) {
        //si el porcentaje de aumento es negativo, se muestra que es un valor invalido 
        if (porcentaje < 0) {
            System.out.println("Porcentaje inválido. Debe ser mayor que 0");
        } else {
            //si es positivo se realiza el aumento
            double aumento = salario * (porcentaje / 100);
            salario += aumento;
            System.out.println("Salario aumentado en " + porcentaje + "%");
        }
    }
}


