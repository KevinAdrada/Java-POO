//este programa muestra el nombre y la nota de un esudiante mediante dos calses, tabien realiza la validacion de la nota.
package estudiante;

//by KevinAdrada
public class Estudiante {
    
    //creamos los atributos privados 
    private String nombre;
    private double nota;
    
    
    //metodo de acceso setter, para iniciar o establecer la variable nombre
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    //metodo de acceso getter para obtener el nombre
    public String getNombre() {
        return nombre;
    }
    
    //metodo de acceso setter, para iniciar o establecer la variable nota
    public void setNota(double nota) {
        
        //realizo la validacion de la nota 
        //si la nota es menor a 0 o mayor a 5 se muestra como nota invalida
        if (nota<0||nota>5) {
        System.out.println(nota + " es una nota invalida");
        this.nota=0;
        }else{
        this.nota = nota;
        }
    }   
    //metodo de acceso getter para obtener el nombre
    public double getNota()  {
        return nota;
    }
    
    //metodo mostrarInfo
    public void MostrarInfo(){
        System.out.println("El nombre es " + nombre + "\nLa nota es " + nota);
    }
}

    

