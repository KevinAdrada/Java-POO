//creamos la clase Main para contener el metodo principal 
package estudiante;


public class Main {
    //creamos el metodo principal 
    public static void main(String[] args) {
        //creamos un objeto
        Estudiante obj = new Estudiante();
        
        //establezco el valor para el atributo nombre
        obj.setNombre("Kevin Santiago");
        
        //muestro el valor en consola del atributo nombre 
        System.out.println();
        
        //establezco un valor para la variable nota
        obj.setNota(6);
        
        //muestro en consola el valor de la nota establecida 
        System.out.println();
        
        //enlazo el metodo mostrarInfo
        obj.MostrarInfo();
    }
}
