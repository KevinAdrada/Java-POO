//este programa simula la venta de un producto teniendo en cuenta el precio y el stock con condiciones establecidas
package producto;

//by KevinAdrada
public class Producto {
    
    //creamos los atributos privados
    private String nombre;
    private double precio;
    private int stock;

    //metodo de acceso setter, para iniciar o establecer la variable nombre
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    //metodo de acceso getter para obtener el nombre
    public String getNombre() {
        return nombre;
    }
    
    
    //metodo de acceso setter, para iniciar o establecer la variable precio
    public void setPrecio(double precio) {
        
        //un producto con un precio menor a 1000 es invalido 
        if(precio<1000){
            System.out.println("El precio es invalido");
            this.precio=1000;
        }else{
            this.precio = precio;
        }
    }
    //metodo de acceso getter para obtener el precio
    public double getPrecio() {
        return precio;
    }
    
    
    //metodo de acceso setter, para iniciar o establecer la variable stock
    public void setStock(int stock) {
        this.stock = stock;
    }
    //metodo de acceso getter para obtener el stock
    public int getStock() {
        return stock;
    }

    
    //metodo vender 
    public void Vender(int cantidad){
        
        //si la cantidad es menor a 0 se muestra como invalido para la venta
        if (cantidad<=0) {
            System.out.println("Cantidad invalida para vender.");
            
        //si es menor o igual al stock se vende y se muestra el stock restante
        } else if (cantidad <= stock) {
            stock -= cantidad;
            System.out.println("Venta de "+cantidad+" productos realizada. Stock restante: " + stock);
            
        //si es superior al stock se muestra que no hay suficiente para vender 
        } else {
            System.out.println("No hay suficiente stock para vender " + cantidad + " unidades.");
        }
    }
    
    
}
