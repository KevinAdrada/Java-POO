
package producto;


public class Main {
    
    //creamos el metodo principal 
    public static void main(String[] args) {
        
        //creamos un objeto
        Producto obj = new Producto();
        
        //establezco un valor para la variable nombre
        obj.setNombre("Portatil");
        
        //muestro en consola el valor del nombre establecido
        System.out.println("El producto es un: "+ obj.getNombre());
        
        //establezco un valores para la variable precio
        obj.setPrecio(800);
        obj.setPrecio(1500);
        
        
        //muestro en consola el valor del precio establecida 
        System.out.println("El precio es: "+ obj.getPrecio());
        
        //establezco un valor para la variable stock
        obj.setStock(15);
        
        //muestro en consola el valor del stock establecida 
        System.out.println("El stock actual para este producto es de: "+ obj.getStock());
        
        //establezco valores para vender 
        obj.Vender(-1);  //cantidad invalida
        obj.Vender(8);   //cantidad valida
        obj.Vender(20);  //cantidad superior al stock 
    }
}
