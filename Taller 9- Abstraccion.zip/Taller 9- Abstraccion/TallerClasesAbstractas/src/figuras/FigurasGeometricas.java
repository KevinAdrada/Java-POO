//este programa utiliza una clase abstracta FigurasGeometricas con un atributo abstracto nombre y un metodo abstracto calcularArea(),
//haciendo que todas sus clases hijas tengan que calcular el area de las figuras dentro de las clases hijas 
package figuras;

//se declara la clase FigurasGeometricas como clase bastracta
public abstract class FigurasGeometricas {
    //creamos el atributo nombre
    String nombre;
    
    //creamos el metodo abstracto calcularArea()
    public abstract void calcularArea();
}
