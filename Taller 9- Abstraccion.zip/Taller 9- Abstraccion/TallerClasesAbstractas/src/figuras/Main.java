
package figuras;


public class Main {
    public static void main(String[] args) {
        
        Circulo obj1= new Circulo();
        Rectangulo obj2= new Rectangulo();
        TrianguloIsosceles obj3= new TrianguloIsosceles();
        TrianguloEscaleno obj4= new TrianguloEscaleno();
        TrianguloEquilatero obj5= new TrianguloEquilatero();
        
        //circulo
        obj1.setNombre("circulo");
        obj1.setRadio(10);
        obj1.calcularArea();
        
        
        //rectangulo
        obj2.setNombre("rectangulo");
        obj2.setBase(2);
        obj2.setAltura(5);
        obj2.calcularArea();
        
        
        //triangulos
        
        //triangulos isosceles
        obj3.setNombre("triangulo Isoceles");
        obj3.setBase(10);
        obj3.setAltura(5);
        obj3.calcularArea();
        
        //triangulo escaleno
        obj4.setNombre("triangulo Escaleno");
        obj4.setBase(20);
        obj4.setAltura(4);
        obj4.calcularArea();
        
        //triangulo equilatero
        obj5.setNombre("triangulo Escaleno");
        obj5.setLado(20);
        obj5.calcularArea();
    }
}
