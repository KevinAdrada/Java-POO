
package figuras;


public class TrianguloEscaleno extends Triangulos{
    private double base;
    private double altura;
    @Override
    public void calcularArea(){
        if (base<=0||altura<=0) {
            System.out.println("Invalido. Uno o mas datos ingresados son menores a 0.");
        }else{
        double area= base*altura/2;
        System.out.println("el area del "+nombre+" es:"+area);
        }
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
    public void setBase(double base) {
        this.base = base;
    }

    public double getBase() {
        return base;
    }

    
    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double getAltura() {
        return altura;
    }
}
