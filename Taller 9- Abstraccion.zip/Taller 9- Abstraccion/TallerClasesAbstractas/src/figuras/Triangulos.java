
package figuras;


public abstract class Triangulos extends FigurasGeometricas{
    
}
