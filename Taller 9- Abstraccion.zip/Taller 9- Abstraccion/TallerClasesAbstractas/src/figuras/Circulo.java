//creamos la clase Circulo
package figuras;

//definimos que la clase Circulo herede los atrinutos y metodos de la clase FigurasGeometricas
public class Circulo extends FigurasGeometricas{
    
    //declaramos la variable pi con un valor constante
    final double pi=3.14;
    //declaro el atributo privado radio
    private double radio;
    
    //usamos el @Override para sobreescribir el metodo calcularArea
    @Override
    public void calcularArea(){
        //utilizo un condicional para que el radio del circulo no sea negativo 
        if (radio<=0) {
            System.out.println("El radio no puede ser menor a 0");
        }else{
            //si es un valor valido se calcula el area del circulo y se muestr en pantalla
        double area=pi*(radio*radio);
        System.out.println("el area del "+nombre+" es:"+area);
        }
    }
    //declaro el setter y getter del atributo nombre
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getNombre() {
        return nombre;
    }
    
    //declaro el setter y getter del atributo radio
    public void setRadio(double radio) {
        this.radio = radio;
    }
    public double getRadio() {
        return radio;
    }
}
