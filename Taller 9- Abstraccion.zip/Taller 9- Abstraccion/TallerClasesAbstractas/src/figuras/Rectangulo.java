//creamos la clase Rectangulo
package figuras;

//definimos que la clase Rectangulo herede los atrinutos y metodos de la clase FigurasGeometricas
public class Rectangulo extends FigurasGeometricas{
    
    //declaro los atributos privados base y altura
    private double base;
    private double altura;
    
    //usamos el @Override para sobreescribir el metodo calcularArea
    @Override
    public void calcularArea(){
        if (base<=0||altura<=0) {
            //utilizo un condicional para que ni la base ni la altura sean igual o menores a 0
            System.out.println("Invalido. Uno o mas datos ingresados son menores a 0.");
        }else{
            //si son valores validos se calcula el area del rectangulo
        double area=base*altura;
        System.out.println("el area del "+nombre+" es:"+area);
        }
    }

    //declaro el setter y getter del atributo nombre
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getNombre() {
        return nombre;
    }

    //declaro el setter y getter del atributo base
    public void setBase(double base) {
        this.base = base;
    }
    public double getBase() {
        return base;
    }

    //declaro el setter y getter del atributo altura
    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double getAltura() {
        return altura;
    }
    
    
}
